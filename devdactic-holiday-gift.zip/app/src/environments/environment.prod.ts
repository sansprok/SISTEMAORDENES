export const environment = {
  production: true,
  apiUrl: 'https://holidaygift.herokuapp.com' // Use your Heroku or hosting URL instead
};
